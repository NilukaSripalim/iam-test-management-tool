package org.iam.test.mgt.tool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestMgtToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestMgtToolApplication.class, args);
	}

}
