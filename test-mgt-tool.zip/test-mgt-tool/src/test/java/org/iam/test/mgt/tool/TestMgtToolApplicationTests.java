package org.iam.test.mgt.tool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestMgtToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
